import customtkinter as ctk
import os
import sys
import json
import webbrowser
from tkinter import messagebox
from regzauth import RegzAuth  # Import backend from regzauth.py

class RegzCheatApp:
    def __init__(self, master):
        self.master = master
        self.root = master
        self.auth = RegzAuth(self)  # Initialize backend
        self.setup_gui()
        self.auth.log_application_open()  # Log app opening

    def setup_gui(self):
        """Initialize the UI"""
        ctk.set_appearance_mode("light")
        ctk.set_default_color_theme("blue")
        self.root.title("Regz Auth Py Example")
        self.root.geometry("510x320")  # Adjusted height for license key field
        self.root.resizable(False, False)
        self.root.configure(fg_color="#151515")

       

        # UI Components
        title_label = ctk.CTkLabel(self.root, text="Regz Auth Py Example", font=("Arial", 28, "bold"), text_color="#FFFFFF")
        title_label.pack(pady=(30, 20))

        self.username_entry = ctk.CTkEntry(self.root, placeholder_text="Username",  height=29, width=320,  text_color="#FFFFFF", fg_color="#2c2c2c")
        self.username_entry.pack(pady=(5, 5))

        self.password_entry = ctk.CTkEntry(self.root, placeholder_text="Password",  height=29,  width=320, text_color="#FFFFFF", fg_color="#2c2c2c")
        self.password_entry.pack(pady=(5, 5))

        self.key_entry = ctk.CTkEntry(self.root, placeholder_text="License Key",  height=29,  width=320, text_color="#FFFFFF", fg_color="#2c2c2c")
        self.key_entry.pack(pady=(5, 10))

        button_login = ctk.CTkButton(self.root, text="Login", command=self.on_login_button_click,  height=28, width=300, fg_color="#00BFFF", hover_color="#00BFFF", text_color="#000000")
        button_login.pack(pady=5)

        button_register = ctk.CTkButton(self.root, text="Register", command=self.on_register_button_click,  height=28, width=300, fg_color="#212121", hover_color="#212121", text_color="#ffffff")
        button_register.pack(pady=5)

        link_buy_account = ctk.CTkLabel(self.root, text="Buy Account", text_color="#00BFFF", cursor="hand2")
        link_buy_account.pack(pady=(5, 0))
        link_buy_account.bind("<Button-1>", lambda e: webbrowser.open("https://regzcheat.org/"))

        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.load_credentials()

    def load_credentials(self):
        """Load saved credentials"""
        appdata = os.getenv("APPDATA") or os.getenv("HOME")
        credentials_file = os.path.join(appdata, "RegzAuthPyExample.json")
        if os.path.exists(credentials_file):
            try:
                with open(credentials_file, "r") as f:
                    credentials = json.load(f)
                    self.username_entry.insert(0, credentials.get("username", ""))
                    self.password_entry.insert(0, credentials.get("password", ""))
            except Exception as e:
                print(f"Error loading credentials: {e}")

    def save_credentials(self, username, password):
        """Save credentials"""
        credentials = {"username": username, "password": password}
        appdata = os.getenv("APPDATA") or os.getenv("HOME")
        credentials_file = os.path.join(appdata, "RegzAuthPyExample.json")
        try:
            with open(credentials_file, "w") as f:
                json.dump(credentials, f)
        except Exception as e:
            print(f"Error saving credentials: {e}")

    def on_login_button_click(self):
        """Handle login button click"""
        username = self.username_entry.get()
        password = self.password_entry.get()
        if not username or not password:
            self.show_message("Please enter username and password.")
            return
        self.auth.check_login(username, password)

    def on_register_button_click(self):
        """Handle register button click"""
        username = self.username_entry.get()
        password = self.password_entry.get()
        license_key = self.key_entry.get()
        if not username or not password or not license_key:
            self.show_message("Please fill in all fields.")
            return
        self.auth.register_user(username, password, license_key)

    def navigate_to_main_screen(self, subscriptions):
        """Navigate to the main screen based on the user's subscription."""
        if "Supreme-Essential-External-Experiment" in subscriptions:
            self.root.withdraw()
            new_root = ctk.CTk()  # Create a new root window
            MainScreen(new_root, subscriptions)  # Pass the subscriptions to the main screen
            new_root.mainloop()
        else:
            self.show_message("Access Denied: You do not have an active subscription.")

    def show_message(self, message):
        """Show a message box with the given message."""
        messagebox.showinfo("Message", message)

    def on_close(self):
        """Handle the close event of the application."""
        self.root.destroy()

class MainScreen:
    def __init__(self, master, subscriptions):
        self.master = master
        self.subscriptions = subscriptions  # List of button names
        self.master.configure(fg_color="#151515")
        ctk.set_appearance_mode("light")
        ctk.set_default_color_theme("blue")
        self.master.title("Regz Auth Py Example")
        self.master.geometry("785x445")
        self.master.resizable(False, False)

        # Add your main screen UI components here
        welcome_label = ctk.CTkLabel(self.master, text="Welcome to Regz Auth Py Example!", font=("Arial", 24, "bold"), text_color="#FFFFFF")
        welcome_label.pack(pady=20)

if __name__ == "__main__":
    root = ctk.CTk()
    app = RegzCheatApp(root)
    root.mainloop()