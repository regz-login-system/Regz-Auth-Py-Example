import os
from supabase import create_client, Client
import hashlib
import datetime
import socket
import platform
import psutil

# Supabase Configuration
SUPABASE_URL = "your-supabase-co-link"
SUPABASE_KEY = "your-supabase-key"
supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)
app_version = "1.0" #your app version
class bishanDatabase:
    @staticmethod
    def connect_to_database():
        """Connect to Supabase database"""
        try:
            print("Attempting to connect to Supabase")
            return supabase
        except Exception as e:
            print(f"Error connecting to database: {e}")
            return None


class RegzAuth:
    def __init__(self, app):
        """Initialize with reference to UI app"""
        self.app = app

    def get_hwid(self):
        """Generate a unique HWID using motherboard serial number"""
        motherboard_serial = os.popen("wmic baseboard get SerialNumber").read().strip().split("\n")[-1]
        hwid = hashlib.sha256(motherboard_serial.encode()).hexdigest()
        return hwid
    def register_user(self, username, password, license_key):
        """Register a new user with a license key"""
        connection = bishanDatabase.connect_to_database()
        if not connection:
            self.app.show_message("Server is under maintenance. Please try again later.")
            return False
    
        try:
            # Check if username already exists
            user_check = connection.table("users").select("id").eq("username", username).execute()
            if user_check.data:
                self.app.show_message("Username already exists. Please choose a different one.")
                return False
    
            # Validate license key (must exist in license_keys to be usable)
            key_data = connection.table("license_keys").select("*").eq("license_key", license_key).execute()
            if not key_data.data:
                self.app.show_message("Invalid or already used license key.")
                return False
    
            key = key_data.data[0]
            if key.get("banned"):
                self.app.show_message("This license key is banned.")
                return False
            if not key.get("admin_approval"):
                self.app.show_message("This license key is not yet approved by an admin.")
                return False
            if key.get("expiredate"):
                expire_date = datetime.datetime.strptime(key["expiredate"], "%Y-%m-%d").date()
                if expire_date < datetime.date.today():
                    self.app.show_message("This license key has expired.")
                    return False

            # Register the user
            hwid = self.get_hwid()
            user_data = {
                "username": username,
                "password": password,
                "key": license_key,
                "hwid": [hwid],
                "subscription": key.get("subscription"),
                "expiredate": key.get("expiredate"),
                "admin_approval": key.get("admin_approval"),
                "max_devices": key.get("max_devices", 1),
            }
            connection.table("users").insert(user_data).execute()
    
            # Remove the license key from license_keys to prevent reuse
            connection.table("license_keys").delete().eq("license_key", license_key).execute()
    
            self.app.show_message("Registration successful! You can now log in.")
            return True
    
        except Exception as e:
            print(f"Error during registration: {e}")
            self.app.show_message(f"Registration Failed: {str(e)}")
            return False

    def check_login(self, username, password):
        """Authenticate user credentials with Supabase"""
        if not self.check_version():
            return

        hwid = self.get_hwid()
        connection = bishanDatabase.connect_to_database()
        if not connection:
            self.app.show_message("Server is under maintenance. Please try again later.")
            return

        try:
            # Check user in Supabase
            user_data = connection.table("users").select("*").eq("username", username).eq("password", password).execute()

            if not user_data.data:
                print(f"Invalid login attempt for username: {username}")
                self.log_login(username, "failed")
                self.app.show_message("Invalid username or password.")
                return

            user = user_data.data[0]

            # Check ban status
            if user.get("banned"):
                print(f"User {username} is banned.")
                self.log_login(username, "failed")
                self.app.show_message("Your account has been banned. You cannot log in.")
                return

            # Check admin approval
            if not user.get("admin_approval"):
                print(f"User {username} has not been approved yet.")
                self.log_login(username, "failed")
                self.app.show_message("Your account is awaiting admin approval.")
                return

            # Check subscription expiry
            expire_date_str = user.get("expiredate")
            if expire_date_str:
                expire_date = datetime.datetime.strptime(expire_date_str, "%Y-%m-%d").date()
                if expire_date < datetime.date.today():
                    print(f"User {username}'s subscription has expired.")
                    self.log_login(username, "failed")
                    self.app.show_message("Your subscription has expired. Please renew to continue.")
                    return

            # HWID verification
            if user.get("save_hwid", True):  # Default to True if not set
                hwid_list = user.get("hwid", []) or []
                max_devices = user.get("max_devices", 1)

                if hwid in hwid_list:
                    self.handle_successful_login(username, password, user)
                elif len(hwid_list) < max_devices:
                    hwid_list.append(hwid)
                    connection.table("users").update({"hwid": hwid_list}).eq("id", user["id"]).execute()
                    self.handle_successful_login(username, password, user)
                else:
                    print(f"User {username} has reached max devices.")
                    self.log_login(username, "failed")
                    self.app.show_message("Your HWID doesn't match or you've reached the maximum device limit.\n\nReset HWID at https://account.regzcheat.org")
            else:
                self.handle_successful_login(username, password, user)

        except Exception as e:
            print(f"Error during login: {e}")
            self.app.show_message(f"Login Failed: {str(e)}")

    def handle_successful_login(self, username, password, user):
        """Process successful login"""
        self.app.save_credentials(username, password)
        self.log_login(username, "success")
        self.save_login_details_to_supabase(username)
        try:
            msg_response = supabase.table("messages").select("text").eq("type", "login_success").single().execute()
            login_message = msg_response.data["text"] if msg_response.data else "Login Successful! Welcome back!"
        except Exception:
            login_message = "Login Successful! Welcome back!"
        self.app.show_message(login_message)
        self.app.navigate_to_main_screen(user.get("subscription", []))

    def check_version(self):
        """Check if app version matches server version"""
        
        try:
            connection = bishanDatabase.connect_to_database()
            if not connection:
                print("Unable to connect to database for version check.")
                self.app.show_message("Failed to connect to server. Please try again later.")
                return False

            server_version_data = connection.table("app_version").select("version").order("id", desc=True).limit(1).execute()
            if server_version_data.data:
                server_version = server_version_data.data[0]["version"]
                print(f"Server version: {server_version}, App version: {app_version}")
                if app_version == server_version:
                    return True
                else:
                    self.app.show_message(f"You are using an outdated version ({app_version}). Please update to version {server_version}.")
                    return False
            else:
                print("No version data found on server.")
                self.app.show_message("Failed to retrieve version information.")
                return False
        except Exception as e:
            print(f"Error checking version: {e}")
            self.app.show_message("Please check your internet connection.")
            return False

    def log_login(self, username, status):
        """Log login attempt to Supabase"""
        try:
            connection = bishanDatabase.connect_to_database()
            if not connection:
                print("Unable to connect to database for logging.")
                return False

            log_data = {
                "username": username,
                "status": status,
                "timestamp": datetime.datetime.now().isoformat()
            }
            connection.table("login_logs").insert(log_data).execute()
            print(f"Login log added for {username} with status: {status}")
            return True
        except Exception as e:
            print(f"Error logging login attempt: {e}")
            return False

    def save_login_details_to_supabase(self, username):
        """Save login details to the Supabase database."""
        try:
            # Collect system details
            system_details = self.get_system_details()
            system_details["username"] = username  # Add username to the details

            # Connect to Supabase and save the data
            connection = bishanDatabase.connect_to_database()
            if not connection:
                print("Unable to connect to the database for saving login details.")
                return False

            connection.table("login_details").insert(system_details).execute()
            print(f"Login details saved for {username}.")
            return True
        except Exception as e:
            print(f"Error saving login details: {e}")
            return False

    def get_system_details(self):
        """Collect system details"""
        try:
            pc_name = socket.gethostname()
            ip_address = socket.gethostbyname(socket.gethostname())
            motherboard_serial = os.popen("wmic baseboard get SerialNumber").read().strip().split("\n")[-1]
            hwid = hashlib.sha256(motherboard_serial.encode()).hexdigest()
            cpu_serial = os.popen("wmic cpu get ProcessorId").read().strip().split("\n")[-1]
            os_version = platform.system() + " " + platform.release()
            ram_capacity = f"{round(psutil.virtual_memory().total / (1024 * 1024 * 1024))} GB"

            graphics_card = "Not Found"
            try:
                gpu_info = os.popen("wmic path win32_videocontroller get caption").read().strip().split("\n")
                graphics_card = gpu_info[1] if len(gpu_info) > 1 else "Not Found"
            except Exception:
                pass

            disk_info = psutil.disk_usage('/')
            storage_capacity = f"{round(disk_info.total / (1024 * 1024 * 1024))} GB"

            return {
                "pc_name": pc_name,
                "ip_address": ip_address,
                "hwid": hwid,
                "motherboard_serial": motherboard_serial,
                "cpu_serial": cpu_serial,
                "os_version": os_version,
                "ram_capacity": ram_capacity,
                "graphics_card": graphics_card,
                "storage_capacity": storage_capacity
            }
        except Exception as e:
            print(f"Error collecting system details: {e}")
            return {}

    def log_application_open(self):
        """Log application open event"""
        try:
            system_details = self.get_system_details()
            system_details["username"] = self.app.username_entry.get() or "unknown"
            system_details["timestamp"] = datetime.datetime.now().isoformat()

            connection = bishanDatabase.connect_to_database()
            if not connection:
                print("Unable to connect to database for logging app open.")
                return

            connection.table("application_open").insert(system_details).execute()
            print(f"Application open logged for {system_details['username']}")
        except Exception as e:
            print(f"Error logging application open: {e}")